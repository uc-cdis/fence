from authlib.client import OAuthClient


__all__ = ["OAuthClient"]
